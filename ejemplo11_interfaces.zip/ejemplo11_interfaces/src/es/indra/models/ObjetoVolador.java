package es.indra.models;

public interface ObjetoVolador {
	
	// Todos los metodos de una interface son publicos y abstractos
	void despegar();
	void aterrizar();
	void volar();

}
