package es.indra.models;

public class Avion extends Vehiculo implements ObjetoVolador{
	
	public Avion(String combustible) {
		super(combustible);
	}

	@Override
	public void despegar() {
		// TODO Auto-generated method stub
		System.out.println("El avion despega");
	}

	@Override
	public void aterrizar() {
		// TODO Auto-generated method stub
		System.out.println("El avion aterriza");
	}

	@Override
	public void volar() {
		// TODO Auto-generated method stub
		System.out.println("El avion vuela");
	}

}
