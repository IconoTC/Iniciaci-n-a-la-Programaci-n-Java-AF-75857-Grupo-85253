package es.indra.models;

public class Pajaro extends Animal implements ObjetoVolador{

	@Override
	public void despegar() {
		// TODO Auto-generated method stub
		System.out.println("El pajaro levanta vuelo");
	}

	@Override
	public void aterrizar() {
		// TODO Auto-generated method stub
		System.out.println("El pajaro se posa");
	}

	@Override
	public void volar() {
		// TODO Auto-generated method stub
		System.out.println("El pajaro vuela");
	}

}
