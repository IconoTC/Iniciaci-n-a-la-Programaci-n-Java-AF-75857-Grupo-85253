package es.indra.models;

public class Animal {
	
	private boolean mamifero;
	private int edad;
	
	public Animal() {
		// TODO Auto-generated constructor stub
	}

	public Animal(boolean mamifero, int edad) {
		super();
		this.mamifero = mamifero;
		this.edad = edad;
	}

	public boolean isMamifero() {
		return mamifero;
	}

	public void setMamifero(boolean mamifero) {
		this.mamifero = mamifero;
	}

	public int getEdad() {
		return edad;
	}

	public void setEdad(int edad) {
		this.edad = edad;
	}
	
}
