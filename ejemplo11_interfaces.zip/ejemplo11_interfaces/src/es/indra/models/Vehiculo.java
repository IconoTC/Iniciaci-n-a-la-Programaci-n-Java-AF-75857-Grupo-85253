package es.indra.models;

public class Vehiculo {
 
	private String combustible;
	
	public Vehiculo() {
		// TODO Auto-generated constructor stub
	}

	public Vehiculo(String combustible) {
		super();
		this.combustible = combustible;
	}

	public String getCombustible() {
		return combustible;
	}

	public void setCombustible(String combustible) {
		this.combustible = combustible;
	}
	
	
}
