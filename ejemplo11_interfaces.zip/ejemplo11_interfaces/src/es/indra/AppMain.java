package es.indra;

import es.indra.models.Avion;
import es.indra.models.Pajaro;

public class AppMain {

	public static void main(String[] args) {
		Avion avion = new Avion("Keroseno");
		avion.despegar();
		avion.volar();
		avion.aterrizar();
		
		
		Pajaro pajaro = new Pajaro();
		pajaro.setMamifero(true);
		pajaro.setEdad(2);
		pajaro.despegar();
		pajaro.volar();
		pajaro.aterrizar();

	}

}
