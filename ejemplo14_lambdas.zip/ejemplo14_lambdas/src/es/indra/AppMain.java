package es.indra;

import es.indra.business.ItfzFuncional;

public class AppMain {

	public static void main(String[] args) {
		// Sintaxis lambdas:  parametros -> cuerpo de la funcion
		
		// Los nombres de los parametros no tienen porque llamarse igual
		// Al ser 2 parametros es obligatorio poner los parentesis
		// No es obligatorio poner el tipo de datos en los parametros
		// Al ser una sola funcion el cuerpo, tampoco es obligatorio poner las {}
		ItfzFuncional lambda1 = (n, e) -> "Nombre: " + n + " Edad: " + e;
		System.out.println(lambda1.infoPersonas("Pepito", 28));
		
		ItfzFuncional lambda2 = (String nombre, int edad) -> "Nombre: " + nombre + " Edad: " + edad;
		System.out.println(lambda2.infoPersonas("Pepito", 28));
		
		// Si ponemos llaves en el cuerpo de la funcion, es obligatorio poner el return
		ItfzFuncional lambda3 = (String nombre, int edad) -> {
			return "Nombre: " + nombre + " Edad: " + edad;
		};
		System.out.println(lambda3.infoPersonas("Pepito", 28));
		
		// Si hay mas de una linea en el cuerpo, las llaves son obligatorias
		ItfzFuncional lambda4 = (String nombre, int edad) -> {
			edad++;
			nombre = nombre.toUpperCase();
			return "Nombre: " + nombre + " Edad: " + edad;
		};
		System.out.println(lambda4.infoPersonas("Pepito", 28));

	}

}
