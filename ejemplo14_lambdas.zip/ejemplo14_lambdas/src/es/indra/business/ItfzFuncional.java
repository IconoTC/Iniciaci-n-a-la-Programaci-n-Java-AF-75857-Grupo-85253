package es.indra.business;

// Una interface funcional tiene que tener solo un metodo abstracto
@FunctionalInterface
public interface ItfzFuncional {
	
	String infoPersonas(String nombre, int edad);

}
