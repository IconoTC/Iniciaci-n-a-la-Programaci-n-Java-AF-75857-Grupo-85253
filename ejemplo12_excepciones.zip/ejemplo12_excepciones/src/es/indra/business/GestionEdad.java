package es.indra.business;

import es.indra.utils.EdadNegativa;

public class GestionEdad {
	
	public void comprobarEdad(int edad) throws EdadNegativa {
		if (edad < 0) {
			// Lanzamos la excepcion personalizada
			throw new EdadNegativa("La edad no puede ser negativa");
		}
	}

}
