package es.indra;

import es.indra.business.GestionEdad;
import es.indra.utils.EdadNegativa;

public class AppMain {

	public static void main(String[] args) {
		
		String datos[] = {"1", "dos", "3", "4", "5"};
		int suma = 0;
		
		for (String dato : datos) {
			int numero = 0;
			
			try {
				numero = Integer.parseInt(dato);
			} catch (NumberFormatException e) {
				System.out.println(e.getMessage());
				e.printStackTrace();
			} catch (Exception e) {
				System.out.println(e.getMessage());
				e.printStackTrace();
			} finally {
				// Siempre se ejecuta haya excepcion o no
				suma += numero;
			}	
		}
		
		System.out.println("Suma: " + suma);
		
		GestionEdad gestion = new GestionEdad();
		try {
			gestion.comprobarEdad(-30);
		} catch (EdadNegativa e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
