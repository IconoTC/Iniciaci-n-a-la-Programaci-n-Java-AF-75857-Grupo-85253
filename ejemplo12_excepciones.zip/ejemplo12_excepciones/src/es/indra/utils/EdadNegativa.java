package es.indra.utils;

public class EdadNegativa extends Exception{
	
	public EdadNegativa(String msg) {
		super(msg);
	}
}
