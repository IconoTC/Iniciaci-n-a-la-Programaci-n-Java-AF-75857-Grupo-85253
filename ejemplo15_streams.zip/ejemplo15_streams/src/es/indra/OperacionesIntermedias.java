package es.indra;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

import es.indra.models.Alumno;

public class OperacionesIntermedias {

	public static void main(String[] args) {
		
		List<Alumno> lista = Arrays.asList(
			new Alumno("Juan", 19, 7.5),
			new Alumno("Maria", 23, 3.9),
			new Alumno("Pedro", 16, 9.2),
			new Alumno("Elena", 20, 4.1),
			new Alumno("Jorge", 15, 8.6),
			new Alumno("Sofia", 17, 2.5));
		
		// Mostrar los menores de edad
		lista.stream()
			.filter(alum -> alum.getEdad() < 18)
			.forEach(System.out::println);
		System.out.println("-------------------");

		// Mostrar solo el nombre de los menores de edad
		lista.stream()
			.filter(alum -> alum.getEdad() < 18)
			.map(a -> a.getNombre())
			.forEach(System.out::println);
		System.out.println("-------------------");
		
		// Mostrar solo el nombre de los menores de edad ordenados ascendente
		lista.stream()
			.filter(alum -> alum.getEdad() < 18)
			.map(a -> a.getNombre())
			.sorted()
			.forEach(System.out::println);
		System.out.println("-------------------");
		
		// Mostrar solo el nombre de los menores de edad ordenados descendente
		lista.stream()
			.filter(alum -> alum.getEdad() < 18)
			.map(a -> a.getNombre())
			.sorted(Comparator.reverseOrder())
			.forEach(System.out::println);
		System.out.println("-------------------");
	}

}
