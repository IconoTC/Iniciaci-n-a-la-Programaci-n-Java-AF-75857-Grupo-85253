package es.indra;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

import es.indra.models.Alumno;

public class OperacionesFinales {

	public static void main(String[] args) {
		List<Alumno> lista = Arrays.asList(
				new Alumno("Juan", 19, 7.5),
				new Alumno("Maria", 23, 3.9),
				new Alumno("Pedro", 16, 9.2),
				new Alumno("Elena", 20, 4.1),
				new Alumno("Jorge", 15, 8.6),
				new Alumno("Sofia", 17, 2.5));
		
		// Cual es el alumno con la nota mas alta
		Alumno maxNota = lista.stream()
				.max(Comparator.comparing(Alumno::getNota))
				.get();
		System.out.println("Alumno maxima nota: " + maxNota);

		
		// Cual es el alumno mas joven
		Alumno minEdad = lista.stream()
				.min(Comparator.comparing(Alumno::getEdad))
				.get();
		System.out.println("Alumno mas joven: " + minEdad);
		
		
		// Media de las notas
		double media = lista.stream()
				.mapToDouble(alum -> alum.getNota())
				.average()
				.getAsDouble();
		System.out.println("Media: " + media);

		
		// Cuantos alumnos han suspendido
		long numSuspensos = lista.stream()
				.filter(alum -> alum.getNota() < 5)
				.count();
		System.out.println("Numero de alumnos suspensos: " + numSuspensos);
	}

}
