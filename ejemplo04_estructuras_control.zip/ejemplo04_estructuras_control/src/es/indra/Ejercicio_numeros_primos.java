package es.indra;

public class Ejercicio_numeros_primos {

	public static void main(String[] args) {
		// Mostrar los numeros primos del 1 al 100
		// un numero es primo cuando solo es divisible por si mismo y la unidad 1
		
		for (int num =1; num <= 100; num++) {
			
			boolean esPrimo = true;
			
			for (int divisor = 2; divisor < num; divisor++) {
				if (num % divisor == 0) {
					esPrimo = false;
					break;
				}
			}
			
			if (esPrimo) {
				System.out.println(num);
			}
			
		}

	}

}
