package es.indra;

import java.util.Scanner;

public class Ejercicio_adivina_numero {

	public static void main(String[] args) {
		/*
		 * crear un numero aleatorio entre 1 y 10
		 * solicitar al usuario que adivine el numero
		 * hay que dar pistas: demasido grande, es pequeño
		 * */
		int num = (int) (Math.random() * 10) + 1;
		int adivina = 0;
		do {
			Scanner sc = new Scanner(System.in);
			System.out.println("Adivina el numero entre 0 y 10: ");
			adivina = sc.nextInt();
			
			if (num > adivina) {
				System.out.println("Te has quedado corto, intenta un numero mayor");
			} else if (num < adivina) {
				System.out.println("Te has pasado, intenta un numero menor");
			} else {
				System.out.println("Has acertado");
				break;
			}
			
		} while (num != adivina);
		
	}

}
