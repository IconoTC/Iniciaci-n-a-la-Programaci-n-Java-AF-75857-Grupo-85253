package es.indra;

import java.util.Scanner;

public class Ejercicio_if_else {

	public static void main(String[] args) {
		/* 
		 * Ejercicio_if_else
		 * 		solicitar una letra al usuario del dia de la semana
		 * 		y mostrar a que dia pertenece
		 * 		puede ser en mayusculas o minusculas
		 * 		m o M -> Es martes
		 * */
		Scanner sc = new Scanner(System.in);
		System.out.println("Introduce dia de la semana (l,m,x,j,v,s,d): ");
		char dia = sc.nextLine().charAt(0);
		
		if (dia == 'l' || dia == 'L') {
			System.out.println("Es lunes");
		} else if (dia == 'm' || dia == 'M') {
			System.out.println("Es martes");
		} else if (dia == 'x' || dia == 'X') {
			System.out.println("Es miercoles");
		} else if (dia == 'j' || dia == 'J') {
			System.out.println("Es jueves");
		} else if (dia == 'v' || dia == 'V') {
			System.out.println("Es viernes");
		} else if (dia == 's' || dia == 'S') {
			System.out.println("Es sabado");
		} else if (dia == 'd' || dia == 'D') {
			System.out.println("Es domingo");
		} else {
			System.out.println("Dia no valido");
		}

	}

}
