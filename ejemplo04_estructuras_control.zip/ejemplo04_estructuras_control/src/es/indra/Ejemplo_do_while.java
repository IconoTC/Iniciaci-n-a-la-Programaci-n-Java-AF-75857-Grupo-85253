package es.indra;

import java.util.Scanner;

public class Ejemplo_do_while {

	public static void main(String[] args) {
		int num = 8;
		int adivina = 0;
		
		do {
			Scanner sc = new Scanner(System.in);
			System.out.println("Adivina el numero entre 0 y 10: ");
			adivina = sc.nextInt();
		} while (num != adivina);
		
		System.out.println("Lo has acertado");
	}
}
