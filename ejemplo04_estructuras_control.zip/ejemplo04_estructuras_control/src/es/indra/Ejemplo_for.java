package es.indra;

public class Ejemplo_for {

	public static void main(String[] args) {
		
		// Mostrar los numeros del 1 al 10
		for (int num=1; num <=10; num++) {
			System.out.print(num + " ");
		}
		System.out.println("");
		

		// Mostrar los numeros del 10 al 1
		for (int num=10; num>0; num--) {
			System.out.print(num + " ");
		}
		System.out.println("");
		
		// Mostrar los numeros del 0 al 10 de 2 en 2
		for (int num=0; num <=10; num+=2) {
			System.out.print(num + " ");
		}
		System.out.println("");
		
		// Unir for y if_else
		// recorrer los numeros del 1 al 50 y mostrar solo los divisibles por 5
		for (int num=1; num <=50; num++) {
			if (num % 5 == 0) {
				System.out.print(num + " ");
			}
		}
		System.out.println("");
		
		// Sumar todos los numeros del array
		int numeros[] = {3,7,1,8};
		int suma = 0;
		for (int num : numeros) {
			suma += num;
		}
		System.out.println("Suma: " + suma);
		
		// Bucles anidados
		// Con bucle for mostrar las tablas de multiplicar del 1 al 10
		for (int tabla=1; tabla <=10; tabla++) {
			System.out.println("****** Tabla del numero " + tabla + " ******");
			for (int num=1; num <=10; num++) {
				System.out.println(tabla + " x " + num + " = " + (tabla * num));
			}
			System.out.println();
		}
	}

}
