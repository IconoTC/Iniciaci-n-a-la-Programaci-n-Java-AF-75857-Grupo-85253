package es.indra;

import java.util.Scanner;

public class Ejemplo_while {

	public static void main(String[] args) {
		int num = 8;
		int adivina = 0;
		while(num != adivina){
			Scanner sc = new Scanner(System.in);
			System.out.println("Adivina el numero entre 0 y 10: ");
			adivina = sc.nextInt();
		}
		System.out.println("Lo has acertado");
	}
}
