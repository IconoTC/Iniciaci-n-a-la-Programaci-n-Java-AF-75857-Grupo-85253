package es.indra;

public class AppMain {

	public static void main(String[] args) {
		int num1 = 8;
		int num2 = 6;
		
		// Operadores aritmeticos
		System.out.println("Suma: " + (num1 + num2) );
		System.out.println("Resta: " + (num1 - num2));
		System.out.println("Multiplicacion: " + (num1 * num2));
		System.out.println("Division: " + (num1 / num2));
		System.out.println("Resto division: " + (num1 % num2));
		
		// pre y post incremento o decremento
		// num1++  postincremento: 1º muestra el numero y luego lo incrementa
		// ++num1  preincremento:  1º incrementa el numero y luego lo muestra
		System.out.println("Incremento: " + ++num1);
		System.out.println("Decremento: " + --num2);
		
		
		// Operadores relacionales
		System.out.println("Mayor: " + (num1 > num2));
		System.out.println("Mayor o igual: " + (num1 >= num2));
		System.out.println("Menor: " + (num1 < num2));
		System.out.println("Menor o igual: " + (num1 <= num2));
		System.out.println("Igualdad: " + (num1 == num2));
		System.out.println("Diferentes: " + (num1 != num2));
		
		
		// Operadores lógicos
		System.out.println((num1 > 1) && (num1 < 10));
		System.out.println((num1 > 10) || (num1 < 20));
		System.out.println(!(num1 > 1));
		System.out.println(!(num1 > 10));
		
		
		// Operadores de asignacion compuesta
		num1 += 5;      // num1 = num1 + 5;
		System.out.println("Num1: " + num1);
		
		num1 -= 5;      // num1 = num1 - 5;
		num1 *= 5;      // num1 = num1 * 5;
		num1 /= 5;      // num1 = num1 / 5;
		num1 %= 5;      // num1 = num1 % 5;
	}

}
