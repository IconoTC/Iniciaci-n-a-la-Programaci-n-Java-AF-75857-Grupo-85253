package es.indra;

public class Main {

	// Es el unico metodo que reconoce la JVM como inicio
	public static void main(String[] args) {
		// syso + Ctrl + space
		System.out.println("Bienvenidos al curso de Java");
	}

}
