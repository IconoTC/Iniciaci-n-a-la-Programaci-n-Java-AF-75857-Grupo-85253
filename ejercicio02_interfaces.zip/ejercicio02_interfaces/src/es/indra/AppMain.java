package es.indra;

import es.indra.models.Animal;
import es.indra.models.Perro;
import es.indra.models.ProductoVenta;

public class AppMain {

	public static void main(String[] args) {
		
		Perro perro = new Perro("Fifi", 2, true, 'M', 295.90, "PE-001");
		Animal animal = new Perro("Fifi", 2, true, 'M', 295.90, "PE-001");
		ProductoVenta productoVenta = new Perro("Fifi", 2, true, 'M', 295.90, "PE-001");
		
		animal.getNombre();
		productoVenta.getCodigo();
		
		System.out.println("Nombre: " + perro.getNombre());
		System.out.println("Edad: " + perro.getEdad());
		System.out.println("Sexo: " + perro.getSexo());
		System.out.println("Esta vacunado? " + perro.isVacunado());
		System.out.println("Precio: " + perro.getPrecio());
		System.out.println("Codigo: " + perro.getCodigo());

	}

}
