package es.indra.models;

public interface ProductoVenta {

	double getPrecio();
	void setPrecio(double precio);
	
	String getCodigo();
	void setCodigo(String codigo);
}
