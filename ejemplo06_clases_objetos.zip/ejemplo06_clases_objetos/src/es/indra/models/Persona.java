package es.indra.models;

public class Persona {
	
	// Caracteristicas, atributos, propiedades, campos
	// acceso tipo nombre;
	// Si no pongo acceso coge default (recurso solo accesibles por clases del mismo paquete)
	public String nombre;    // Un recurso publico es accesible desde cualquier clase del proyecto
	public int edad;
	public String nif;
	
	
	// En el momento de la compilacion si detecta que no hay ningun constructor, agrega el constructor por defecto.
	// si ya hay algun constructor, no agrega nada. Por eso es importante mantener el constructor por defecto
	public Persona() {
		// TODO Auto-generated constructor stub
	}
	
	public Persona(String nombre, int edad, String nif) {
		super();
		this.nombre = nombre;
		this.edad = edad;
		this.nif = nif;
	}
	
	// Acciones, funciones, metodos
	// acceso tipo_retorno nombre(lista_parametros){}
	public void mostrarInfo() {
		System.out.println("Nombre: " + nombre + " Edad: " + edad + " Nif: " + nif);
	}

}
