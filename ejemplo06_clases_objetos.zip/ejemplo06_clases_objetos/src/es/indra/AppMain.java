package es.indra;

import es.indra.models.Persona;

public class AppMain {

	public static void main(String[] args) {
		
		// Tipo variable = new Constructor();
		Persona p1 = new Persona();
		
		// Quiero personalizar mi objeto
		p1.nombre = "Juan";   // el punto . es el operador de acceso a miembro
		p1.edad = 37;
		p1.nif = "12345678-A";
		
		// Mostrar el objeto en consola
		System.out.println(p1);   // es.indra.models.Persona@15db9742
		p1.mostrarInfo();
		
		// Creamos otra instancia de Persona utilizando el constructor completo
		Persona p2 = new Persona("Maria", 42, "98765432-D");
		p2.mostrarInfo();

	}

}
