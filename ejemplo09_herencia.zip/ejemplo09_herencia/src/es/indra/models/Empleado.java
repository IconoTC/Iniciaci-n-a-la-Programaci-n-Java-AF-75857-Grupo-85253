package es.indra.models;

import java.util.Objects;

public class Empleado extends Persona{

	private double sueldo;
	
	public Empleado() {
		// La llamada super() es implicita
		super();  // Si no existe el constructor por defecto en Persona daria error
	}

	public Empleado(String nombre, int edad, String nif, Direccion direccion, double sueldo) {
		// Esta llamando al constructor de la superclase
		super(nombre, edad, nif, direccion);
		this.sueldo = sueldo;
	}

	public double getSueldo() {
		return sueldo;
	}

	public void setSueldo(double sueldo) {
		this.sueldo = sueldo;
	}

	@Override
	public String mostrarInfo() {
		// el puntero super. apunta a la instancia de la superclase
		return super.mostrarInfo() + " sueldo: " + sueldo;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + Objects.hash(sueldo);
		return result + super.hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Empleado other = (Empleado) obj;
		return super.equals(obj) && Double.doubleToLongBits(sueldo) == Double.doubleToLongBits(other.sueldo);
	}

	@Override
	public String toString() {
		return "Empleado [sueldo=" + sueldo + ", toString()=" + super.toString() + "]";
	}

	

}
