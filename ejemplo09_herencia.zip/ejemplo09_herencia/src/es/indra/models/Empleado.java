package es.indra.models;

public class Empleado extends Persona{

	private double sueldo;
	
	public Empleado() {
		// La llamada super() es implicita
		super();  // Si no existe el constructor por defecto en Persona daria error
	}

	public Empleado(String nombre, int edad, String nif, Direccion direccion, double sueldo) {
		// Esta llamando al constructor de la superclase
		super(nombre, edad, nif, direccion);
		this.sueldo = sueldo;
	}

	public double getSueldo() {
		return sueldo;
	}

	public void setSueldo(double sueldo) {
		this.sueldo = sueldo;
	}

	@Override
	public String mostrarInfo() {
		// el puntero super. apunta a la instancia de la superclase
		return super.mostrarInfo() + " sueldo: " + sueldo;
	}

	
	
	
}
