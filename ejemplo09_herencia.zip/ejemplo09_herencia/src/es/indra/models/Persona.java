package es.indra.models;

import java.util.Objects;

// En el momento de la compilacion, si la clase no hereda de ninguna otra
// el compilador añade extends Object
public class Persona {
	
	private String nombre;    
	private int edad;
	private String nif;
	private Direccion direccion;
	
	public Persona() {
		// TODO Auto-generated constructor stub
	}
	
	public Persona(String nombre, int edad, String nif, Direccion direccion) {
		super();
		this.nombre = nombre;
		this.edad = edad;
		this.nif = nif;
		this.direccion = direccion;
	}

	public String mostrarInfo() {
		return "Nombre: " + nombre + " Edad: " + edad + " Nif: " + nif 
				+ " Direccion: " + direccion.mostrarInfo();
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getEdad() {
		return edad;
	}

	public void setEdad(int edad) {
		this.edad = edad;
	}

	public String getNif() {
		return nif;
	}

	public void setNif(String nif) {
		this.nif = nif;
	}

	public Direccion getDireccion() {
		return direccion;
	}

	public void setDireccion(Direccion direccion) {
		this.direccion = direccion;
	}

	@Override
	public int hashCode() {
		return Objects.hash(edad, nif, nombre);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		// Cambio la visibilidad del objeto
		Persona other = (Persona) obj;  // Casting
		return edad == other.edad && Objects.equals(nif, other.nif) && Objects.equals(nombre, other.nombre);
	}

	@Override
	public String toString() {
		return "Persona [nombre=" + nombre + ", edad=" + edad + ", nif=" + nif + ", direccion=" + direccion + "]";
	}
	
	
	
}
