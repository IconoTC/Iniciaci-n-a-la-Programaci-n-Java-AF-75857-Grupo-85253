package es.indra;

import es.indra.models.Direccion;
import es.indra.models.Empleado;
import es.indra.models.Persona;

public class AppMain {

	public static void main(String[] args) {
		
		Persona p1 = new Persona();
		p1.setNombre("Juan");
		p1.setEdad(37);
		p1.setNif("12345678-A");
		p1.setDireccion(new Direccion("Mayor", 127, "Madrid"));
		System.out.println(p1.mostrarInfo());
		System.out.println(p1);
		
		Empleado empleado = new Empleado("Maria", 42, "98765432-D", 
				new Direccion("Diagonal", 29, "Barcelona"), 42000);
		System.out.println(empleado.mostrarInfo());
		System.out.println(empleado);
		
		Empleado empleado2 = new Empleado("Maria", 42, "98765432-D", 
				new Direccion("Diagonal", 29, "Barcelona"), 42000);

		int num1 = 8;
		int num2 = 8;
		System.out.println("Son iguales los numeros? " + (num1 == num2));
		System.out.println("Son iguales los empleados? " + (empleado == empleado2));
		
		// El operador == compara el contenido de las variables
		// Esto es un problema porque si lo utilizamos para comparar objetos, compara direcciones de memoria
		
		// Los objetos se comparan con el metodo equals heredado de la clase Object
		System.out.println("Son iguales los empleados? " + (empleado.equals(empleado2)));
	}
	
}
