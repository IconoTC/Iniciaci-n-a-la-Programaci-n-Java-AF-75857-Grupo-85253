package es.indra;


import es.indra.models.Circulo;
import es.indra.models.Figura;
import es.indra.models.Rectangulo;

public class AppMain {

	public static void main(String[] args) {
		
		// Ejemplo de polimorfismo
		Figura rectangulo = new Rectangulo(10,20, 350,125 );
		System.out.println(rectangulo);
		System.out.println("Area del rectangulo: " + rectangulo.calcularArea());
		
		// Ahora el rectangulo lo veo como una Figura
		// rectangulo.getBase();  // ERROR
		// Cambio la visibilidad
		Rectangulo miRectangulo = (Rectangulo) rectangulo;
		miRectangulo.getBase();
		
		// Una clase abstracta se puede utilizar como tipo, pero no se puede instanciar
		// Figura figura = new Figura(10,20);
		
		Figura circulo = new Circulo(30,15,  20.45);
		System.out.println(circulo);
		System.out.println("Area del circulo: " + circulo.calcularArea());
		System.out.println("Coordenadas del circulo: " + "[" + circulo.getX() + "," + circulo.getY() + "]");

	}

}
