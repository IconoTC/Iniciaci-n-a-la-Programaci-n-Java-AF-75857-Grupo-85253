package es.indra.models;

// Toda clase que tiene un metodo abstracto, hay que declararla como abstracta
public abstract class Figura {
	
	private double x;
	private double y;
	
	public Figura() {
		// TODO Auto-generated constructor stub
	}

	public Figura(double x, double y) {
		super();
		this.x = x;
		this.y = y;
	}
	
	// Un metodo abstracto, es un metodo declarado pero no implementado
	public abstract double calcularArea();

	public double getX() {
		return x;
	}

	public void setX(double x) {
		this.x = x;
	}

	public double getY() {
		return y;
	}

	public void setY(double y) {
		this.y = y;
	}

	@Override
	public String toString() {
		return "Figura [x=" + x + ", y=" + y + "]";
	}
	
}
