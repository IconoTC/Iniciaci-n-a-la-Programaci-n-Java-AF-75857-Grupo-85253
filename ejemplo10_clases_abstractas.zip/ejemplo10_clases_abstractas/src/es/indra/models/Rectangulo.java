package es.indra.models;

public class Rectangulo extends Figura{

	private double base;
	private double altura;
	
	public Rectangulo() {
		// TODO Auto-generated constructor stub
	}

	public Rectangulo(double x, double y, double base, double altura) {
		super(x, y);
		this.base = base;
		this.altura = altura;
	}
	
	// Implementamos el metodo abstracto que hemos heredado de Figura
	// Si no lo hiciesemos, tenemos que declarar la clase Rectangulo como abstracta
	// Eso no me interesa, porque una clase abstracta la puedo utilizar como tipo de dato
	// pero no la puedo instanciar
	@Override
	public double calcularArea() {
		return base * altura;
	}

	public double getBase() {
		return base;
	}

	public void setBase(double base) {
		this.base = base;
	}

	public double getAltura() {
		return altura;
	}

	public void setAltura(double altura) {
		this.altura = altura;
	}

	@Override
	public String toString() {
		return "Rectangulo [base=" + base + ", altura=" + altura + ", toString()=" + super.toString() + "]";
	}	
	
}
