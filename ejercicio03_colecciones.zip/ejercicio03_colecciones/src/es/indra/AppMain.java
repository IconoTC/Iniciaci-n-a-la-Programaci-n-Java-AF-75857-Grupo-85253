package es.indra;

import java.util.Set;
import java.util.TreeSet;

import es.indra.models.Alumno;
import es.indra.utils.ComparadorEdad;
import es.indra.utils.ComparadorNombre;
import es.indra.utils.ComparadorNota;

public class AppMain {

	public static void main(String[] args) {
		
		Set<Alumno> arbol = new TreeSet<>(new ComparadorEdad());
		arbol.add(new Alumno("Juan", 16, 7.5));
		arbol.add(new Alumno("Maria", 22, 8.3));
		arbol.add(new Alumno("Pedro", 19, 5.9));
		for (Alumno alumno : arbol) {
			System.out.println(alumno);
		}

	}

}
