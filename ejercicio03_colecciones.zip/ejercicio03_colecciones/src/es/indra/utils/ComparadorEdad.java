package es.indra.utils;

import java.util.Comparator;

import es.indra.models.Alumno;

public class ComparadorEdad implements Comparator<Alumno>{

	@Override
	public int compare(Alumno alum1, Alumno alum2) {
		if (alum1.getEdad() > alum2.getEdad()) {
			return 1;
		} else if (alum1.getEdad() < alum2.getEdad()) {
			return -1;
		} else {
			return 0;
		}	
	}

}
