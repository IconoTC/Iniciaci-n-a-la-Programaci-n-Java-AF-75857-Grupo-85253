package es.indra.utils;

import java.util.Comparator;

import es.indra.models.Alumno;

public class ComparadorNota implements Comparator<Alumno>{

	@Override
	public int compare(Alumno alum1, Alumno alum2) {
		// 1 o cualquier positivo si alum1 es mayor que alum2
		// -1 o cualquier negativo si alum1 es menor que alum2
		// 0 cuando son iguales
		if (alum1.getNota() > alum2.getNota()){
			return 1;
		} else if (alum1.getNota() < alum2.getNota()){
			return -1;
		} else {
			return 0;
		}
	}

}
