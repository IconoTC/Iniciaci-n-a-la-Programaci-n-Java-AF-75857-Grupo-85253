package es.indra.utils;

import java.util.Comparator;

import es.indra.models.Alumno;

public class ComparadorNombre implements Comparator<Alumno>{

	@Override
	public int compare(Alumno alum1, Alumno alum2) {
		return alum1.getNombre().compareTo(alum2.getNombre());
	}

}
