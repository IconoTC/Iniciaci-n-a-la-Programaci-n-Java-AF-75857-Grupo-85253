package es.indra;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import es.indra.models.Alumno;

public class AppMain {

	public static void main(String[] args) {
		
		// Crear el arbol clasificando por nombre utilizando lambdas
		Set<Alumno> arbol = new TreeSet<>((a1,a2) -> a1.getNombre().compareTo(a2.getNombre()));
		arbol.add(new Alumno("Juan", 16, 7.5));
		arbol.add(new Alumno("Maria", 22, 8.3));
		arbol.add(new Alumno("Pedro", 19, 5.9));
		for (Alumno alumno : arbol) {
			System.out.println(alumno);
		}
		System.out.println("-------------------");
		
		List<Alumno> alumnos = new ArrayList<>(arbol);
		// Mostrar la lista ordenada por nota utilizando lambdas		
		alumnos.sort((alum1,alum2) -> {
			if (alum1.getNota() > alum2.getNota()){
				return 1;
			} else if (alum1.getNota() < alum2.getNota()){
				return -1;
			} else {
				return 0;
			}
		});
		for (Alumno alumno : alumnos) {
			System.out.println(alumno);
		}
		System.out.println("-------------------");

		// Mostrar la lista ordenada por edad utilizando lambdas
		alumnos.sort((alum1,alum2) -> {
			if (alum1.getEdad() > alum2.getEdad()){
				return 1;
			} else if (alum1.getEdad() < alum2.getEdad()){
				return -1;
			} else {
				return 0;
			}
		});
		for (Alumno alumno : alumnos) {
			System.out.println(alumno);
		}
		System.out.println("-------------------");
		
		// Mostrar la lista ordenada por nota utilizando lambdas		
		alumnos.sort(Comparator.comparingDouble(Alumno::getNota));
		alumnos.forEach(System.out::println);
		System.out.println("-------------------");
	}

}
