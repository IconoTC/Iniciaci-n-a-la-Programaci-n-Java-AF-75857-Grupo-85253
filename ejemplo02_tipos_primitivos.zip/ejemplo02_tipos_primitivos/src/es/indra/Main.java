package es.indra;

public class Main {

	public static void main(String[] args) {
		// Tipos enteros
		byte numByte = 6;        // 8 bits
		short numSort = 786;     // 16 bits
		int numInteger = 76452;  // defecto   32 bits
		long numLong = 7654325689865433L;   // 64 bits
		
		
		// Tipos reales
		float numFloat = 3.14F;    // 32 bits
		double numDouble = 365658484.1486754;   // defecto   64 bits
		
		
		// Tipos booleanos
		boolean tipoBoolean = false;
		
		
		// Tipo textual
		char caracter = '%';   // siempre entre comillas simples
		
		
		// Clase String para manejar cadenas de texto
		// simpre entre comillas dobles
		// No es un tipo primitivo
		String mensaje = "Bienvenidos al curso de Java";
	}

}
