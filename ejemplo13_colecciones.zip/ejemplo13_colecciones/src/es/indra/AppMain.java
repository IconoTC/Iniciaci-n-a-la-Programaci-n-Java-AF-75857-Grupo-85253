package es.indra;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class AppMain {

	public static void main(String[] args) {
		// Set -> No permite duplicados, no garantiza el orden de entrada
		// List -> Si permite duplicados, si garantiza el orden de entrada

		Set set = new HashSet();
		set.add('c');
		set.add(1);
		set.add("Viernes");
		set.add(true);
		set.add('a');
		set.add('b');
		set.add("Viernes"); // Ignora los valores duplicados
		System.out.println(set);
		
		List lista = new ArrayList();
		lista.add('c');
		lista.add(1);
		lista.add("Viernes");
		lista.add(true);
		lista.add('a');
		lista.add('b');
		lista.add("Viernes");
		System.out.println(lista);
		
		for (Object obj : lista) {
			System.out.println(obj);
		}
		System.out.println("-----------------");
		
		Iterator it = lista.listIterator();
		while(it.hasNext()) {
			Object obj = it.next();
			System.out.println(obj);
		}
		System.out.println("-----------------");
		
		// Map -> Los elementos estan formados por un par clave-valor
		// Las claves no se pueden repetir, los valores si
		// No garantiza el orden de entrada
		Map mapa = new HashMap();
		mapa.put(1, "Hola");
		mapa.put(true, "Adios");
		mapa.put('a', 3);
		mapa.put(1, false); // Si repetimos clave se sobreescribe el valor
		System.out.println(mapa);
		System.out.println("Keys: " + mapa.keySet());
		System.out.println("Values: " + mapa.values());
		System.out.println("Elementos: " + mapa.entrySet());
		
	}

}
