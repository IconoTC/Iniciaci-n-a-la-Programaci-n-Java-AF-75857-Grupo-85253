package es.indra;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class Genericos {

	public static void main(String[] args) {
		// Set -> No permite duplicados, no garantiza el orden de entrada
		// List -> Si permite duplicados, si garantiza el orden de entrada

		Set<Character> set = new HashSet<>();
		set.add('c');
		set.add('a');
		set.add('b');
		System.out.println(set);
		
		List<Integer> lista = new ArrayList<>();
		lista.add(2);
		lista.add(1);
		lista.add(3);
		lista.add(8);
		System.out.println(lista);
		
		for (Integer num : lista) {
			System.out.println(num);
		}
		System.out.println("-----------------");
		
		Iterator<Integer> it = lista.listIterator();
		while(it.hasNext()) {
			int num = it.next();
			System.out.println(num);
		}
		System.out.println("-----------------");
		
		// Map -> Los elementos estan formados por un par clave-valor
		// Las claves no se pueden repetir, los valores si
		// No garantiza el orden de entrada
		Map<Integer,String> mapa = new HashMap<>();
		mapa.put(1, "Hola");
		mapa.put(2, "Adios");
		mapa.put(3, "Pepito");
		mapa.put(4, "Miguelito"); 
		System.out.println(mapa);
		System.out.println("Keys: " + mapa.keySet());
		System.out.println("Values: " + mapa.values());
		System.out.println("Elementos: " + mapa.entrySet());
		
	}

}
