package es.indra.models;

public class Persona {
	
	private String nombre;    
	private int edad;
	private String nif;
	private Direccion direccion;
	
	public Persona() {
		// TODO Auto-generated constructor stub
	}
	
	public Persona(String nombre, int edad, String nif, Direccion direccion) {
		super();
		this.nombre = nombre;
		this.edad = edad;
		this.nif = nif;
		this.direccion = direccion;
	}

	public void mostrarInfo() {
		System.out.println("Nombre: " + nombre + " Edad: " + edad + " Nif: " + nif 
				+ " Direccion: " + direccion.mostrarInfo());
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getEdad() {
		return edad;
	}

	public void setEdad(int edad) {
		this.edad = edad;
	}

	public String getNif() {
		return nif;
	}

	public void setNif(String nif) {
		this.nif = nif;
	}

	public Direccion getDireccion() {
		return direccion;
	}

	public void setDireccion(Direccion direccion) {
		this.direccion = direccion;
	}
	
}
