package es.indra;

import es.indra.models.Direccion;
import es.indra.models.Persona;

public class AppMain {

	public static void main(String[] args) {
		
		Persona p1 = new Persona();
		p1.setNombre("Juan");
		p1.setEdad(37);
		p1.setNif("12345678-A");
		p1.setDireccion(new Direccion("Mayor", 127, "Madrid"));
		p1.mostrarInfo();
		
		// Creamos otra instancia de Persona utilizando el constructor completo
		Persona p2 = new Persona("Maria", 42, "98765432-D", new Direccion("Diagonal", 19, "Barcelona"));
		p2.mostrarInfo();

	}
	
}
