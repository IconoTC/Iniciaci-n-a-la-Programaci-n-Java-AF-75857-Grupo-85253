package es.indra;

public class Ejemplo_arrays {

	public static void main(String[] args) {
		
		// Declarar una variable de tipo array
		int numeros[];
		int [] numeros2;
		int[] numeros3;
		
		int [] n1,n2;  // ambas son arrays
		int n3[], n4;  // solo n3 es array y n4 es una variable de tipo entero
		
		
		// Crear el array
		numeros = new int[5];   // 5 elementos -> length (longitud del array)
		
		// Asignar elementos
		// array[indice] = valor
		numeros[0] = 7;
		numeros[1] = 3;
		numeros[2] = 1;
		numeros[3] = 4;
		numeros[4] = 8;
		// numeros[5] = 2;   ERROR!!! nunca existe un indice con la longitud del array
		// los indices del array van 0 ... length-1
		
		// Todo en uno: declarar, crear y asignar
		int numeros1[] = {7,3,1,4,8};
		//int numeros1[] = new int[]{7,3,1,4,8};
		
		// Recorrer con for tradicional
		for (int indice = 0; indice < numeros.length; indice++) {
			System.out.println(numeros[indice]);
		}
		System.out.println("------------------");
		
		// Recorrer con for each
		for (int numero : numeros1) {
			System.out.println(numero);
		}
		System.out.println("------------------");
		
		// Los arrays no son redimensionables
		int grande[] = new int[10];
		System.arraycopy(numeros, 0, grande, 0, numeros.length);
		for (int numero : grande) {
			System.out.println(numero);
		}
	}

}
