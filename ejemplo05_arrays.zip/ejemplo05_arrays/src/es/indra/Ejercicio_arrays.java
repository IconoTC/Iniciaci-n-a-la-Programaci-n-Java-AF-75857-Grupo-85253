package es.indra;

public class Ejercicio_arrays {

	public static void main(String[] args) {
		int numeros[] = {8,2,5,1,9,7,3,4};
		
		// Mostrar la suma de los numeros pares
		int suma = 0;
		for (int num : numeros) {
			if (num % 2 == 0) {
				suma += num;
			}
		}
		System.out.println("Suma numeros pares: " + suma);
		
		// Mostrar la suma de los numeros impares
		suma = 0;
		for (int num : numeros) {
			if (num % 2 != 0) {
				suma += num;
			}
		}
		System.out.println("Suma numeros impares: " + suma);
		
		// Mostrar la suma de los numeros que estan en un indice par
		suma = 0;
		for (int idx = 0; idx < numeros.length; idx++) {
			if (idx % 2 == 0) {
				suma += numeros[idx];
			}
		}
		System.out.println("Suma numeros indice par: " + suma);
		
		// Mostrar la suma de los numeros que estan en un indice impar
		suma = 0;
		for (int idx = 0; idx < numeros.length; idx++) {
			if (idx % 2 != 0) {
				suma += numeros[idx];
			}
		}
		System.out.println("Suma numeros indice impar: " + suma);
	}

}
