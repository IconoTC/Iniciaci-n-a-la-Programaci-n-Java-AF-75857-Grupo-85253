package es.indra;

import java.util.Arrays;

public class Ejercicio_matrices {

	public static void main(String[] args) {
		
		int numeros[][] = { {4,7,9}, {1,3,5}, {8,2,6} };
		
		// Mostrar la suma de la diagonal principal (4 + 3 + 6)
		int suma = 0;
		for (int idxFila = 0; idxFila < numeros.length; idxFila++){
			for (int idxCol = 0; idxCol < numeros[idxFila].length; idxCol++) {
				if (idxFila == idxCol) {
					suma += numeros[idxFila][idxCol];
				}
			}
		}
		System.out.println("Suma de la digonal principal: " + suma);
		
		
		// Crear un array (1 dimension) con la suma de cada fila {20, 9, 16}
		int resultado[] = new int[numeros.length];   // 3
		for (int idxFila = 0; idxFila < numeros.length; idxFila++) {
			suma = 0;
			for (int num : numeros[idxFila]) {
				suma += num;
			}
			resultado[idxFila] = suma;
		}
		
		System.out.println(resultado);
		System.out.println(Arrays.toString(resultado));

	}

}
