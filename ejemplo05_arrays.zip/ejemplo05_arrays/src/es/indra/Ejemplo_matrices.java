package es.indra;

import java.util.Arrays;

public class Ejemplo_matrices {

	public static void main(String[] args) {
		
		int numeros[][] = new int[2][3];   // matriz de 2 filas y 3 columnas
		//numeros[fila][columna] = valor;
		numeros[0][0] = 6;
		numeros[0][1] = 4;
		numeros[0][2] = 9;
		numeros[1][0] = 1;
		numeros[1][1] = 8;
		numeros[1][2] = 3;
		
		// Todo en uno: declarar, crear, asignar
		int numeros1[][] = { {6,4,9}, {1,8,3} };
		
		// Recorrer con for tradicional
		for (int idxFila = 0; idxFila < numeros.length; idxFila++) {
			for (int idxCol = 0; idxCol < numeros[idxFila].length; idxCol++) {
				System.out.print(numeros[idxFila][idxCol] + " ");
			}
			System.out.println();
		}
		System.out.println("------------------");
		
		
		// Recorrer con for each
		for (int[] fila : numeros1) {
			for (int num : fila) {
				System.out.print(num + " ");
			}
			System.out.println();
		}
		
		// Mostrar la matriz en consola
		System.out.println(numeros);
		System.out.println(Arrays.toString(numeros));
		System.out.println(Arrays.deepToString(numeros));
	}

}
