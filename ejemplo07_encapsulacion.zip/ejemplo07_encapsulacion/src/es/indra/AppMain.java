package es.indra;

import es.indra.models.Fecha;
import es.indra.models.FechaEncapsulada;

public class AppMain {

	public static void main(String[] args) {
		
		Fecha hoy = new Fecha();
		hoy.dia = 19;
		hoy.mes = 11;
		hoy.anyo = 2025;
		hoy.mostrarFecha();
		
		Fecha erronea = new Fecha();
		erronea.dia = 523;
		erronea.mes = -26;
		erronea.anyo = 189;
		erronea.mostrarFecha();
		
		FechaEncapsulada correcta = new FechaEncapsulada();
		//correcta.setDia(523);
		correcta.setDia(19);
		//correcta.setMes(-26);
		correcta.setMes(11);
		//correcta.setAnyo(189);
		correcta.setAnyo(2025);
		correcta.mostrarFecha();

	}

}
