package es.indra.models;

public class Fecha {
	
	public int dia;
	public int mes;
	public int anyo;
	
	public void mostrarFecha() {
		//   19/11/2025
		System.out.println(dia + "/" + mes + "/" + anyo);
	}

}
