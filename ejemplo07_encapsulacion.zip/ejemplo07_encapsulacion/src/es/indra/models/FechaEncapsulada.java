package es.indra.models;

public class FechaEncapsulada {
	
	// Cuando un recurso es privado solo es accesible desde dentro de la clase
	private int dia;
	private int mes;
	private int anyo;
	
	// Metodos de acceso (getter y setter)
	public int getDia() {
		return dia;
	}

	public void setDia(int dia) {
		if (dia > 0 && dia <= 31)
			this.dia = dia;
		else 
			System.out.println("Dia no valido");
	}

	public int getMes() {
		return mes;
	}

	public void setMes(int mes) {
		if (mes >= 1 && mes <= 12)
			this.mes = mes;
		else
			System.out.println("Mes no valido");
	}

	public int getAnyo() {
		return anyo;
	}

	public void setAnyo(int anyo) {
		if (anyo == 2025 || anyo == 2026)
			this.anyo = anyo;
		else
			System.out.println("Año no valido");
	}
	
	public void mostrarFecha() {
		//   19/11/2025
		System.out.println(dia + "/" + mes + "/" + anyo);
	}

}
